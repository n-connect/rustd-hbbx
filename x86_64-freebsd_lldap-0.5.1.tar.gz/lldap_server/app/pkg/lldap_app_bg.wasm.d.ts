/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export function run_app(a: number): void;
export function __wbindgen_malloc(a: number): number;
export function __wbindgen_realloc(a: number, b: number, c: number): number;
export const __wbindgen_export_2: WebAssembly.Table;
export function wasm_bindgen__convert__closures__invoke1_mut_ref__h71cf0487616ba70e(a: number, b: number, c: number): void;
export function wasm_bindgen__convert__closures__invoke1_mut_ref__h64e82cb66d069d06(a: number, b: number, c: number): void;
export function wasm_bindgen__convert__closures__invoke1_mut__h1eb6bdec4aeb3e2d(a: number, b: number, c: number): void;
export function wasm_bindgen__convert__closures__invoke1__h33d68e0cb6f4fc55(a: number, b: number, c: number): void;
export function __wbindgen_free(a: number, b: number): void;
export function __wbindgen_exn_store(a: number): void;
export function __wbindgen_add_to_stack_pointer(a: number): number;
