/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const run_app: () => [number, number];
export const wasm_bindgen__convert__closures________invoke__hceb9f803f9cc7752: (a: number, b: number, c: any) => void;
export const wasm_bindgen__closure__destroy__h47c67a492582dbb5: (a: number, b: number) => void;
export const wasm_bindgen__convert__closures_____invoke__h119bb24af2993762: (a: number, b: number, c: any) => void;
export const wasm_bindgen__closure__destroy__h23e44f8928b05fc7: (a: number, b: number) => void;
export const wasm_bindgen__convert__closures_____invoke__haa8bc4ae37e499fe: (a: number, b: number, c: any) => void;
export const __wbindgen_malloc: (a: number, b: number) => number;
export const __wbindgen_realloc: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_exn_store: (a: number) => void;
export const __externref_table_alloc: () => number;
export const __wbindgen_externrefs: WebAssembly.Table;
export const __wbindgen_free: (a: number, b: number, c: number) => void;
export const __externref_drop_slice: (a: number, b: number) => void;
export const __externref_table_dealloc: (a: number) => void;
export const __wbindgen_start: () => void;
